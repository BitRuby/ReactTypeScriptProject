export interface ToastProps {
  onClose: () => void;
  show: boolean;
}
