import styled from "styled-components";

export const CardsContainer = styled.div`
  width: 565px;
  margin: 0 auto;
`;
