import React from 'react';

export default function Progress() {
    return(
        <div></div>
    );
}