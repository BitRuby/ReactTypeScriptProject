export const COLORS = {
  GREEN: "#27ae60",
  BLUE: "#2980b9",
  RED: "#c0392b",
  ORANGE: "#f39c12",
  GRAY: "#7f8c8d",
};
